jQuery(function () {
    new jBox('Tooltip', {
        attach: '.pp-melange-jbox',
        maxWidth: 200,
        theme: 'TooltipDark'
    });
});