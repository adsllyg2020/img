<?php

namespace ProfilePress\Core\Membership\Models\Coupon;

class CouponApplication
{
    const NEW_PURCHASE = 'acquisition';
    const EXISTING_PURCHASE = 'retention';
    const ANY_PURCHASE = 'any';
}