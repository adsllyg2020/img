<?php

namespace ProfilePress\Core\Admin\SettingsPages\Membership\DashboardPage;

class ReportInterval
{
    const HOURLY = 'hour';
    const DAILY = 'day';
    const MONTHLY = 'month';
    const YEARLY = 'year';
}