<?php

namespace ProfilePress\Core\Admin\SettingsPages\Membership\DashboardPage;

class ReportFilterData
{
    public $start_date;
    public $end_date;
    public $plan_id;
}